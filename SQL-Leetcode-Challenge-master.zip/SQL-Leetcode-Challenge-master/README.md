# SQL-Leetcode-Challenge 

## Motivation
This repo contains all my SQL solutions from Leetcode website in order to practice my SQL programming skills. I attempted all questions in 25 days to corroborate my knowledge in SQL.

## Description
The solutions are divided into three level of categories namely Easy, Medium, and Hard. Every category first contains the question and then followed by its respective solution.
Link to the website is: https://leetcode.com/problemset/database/

